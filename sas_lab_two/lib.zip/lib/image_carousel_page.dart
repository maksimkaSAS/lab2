import 'package:flutter/material.dart';
import 'package:sas_lab_two/widgets/image_carousel_widget.dart';

class ImageCarouselPage extends StatelessWidget {
  final String imageUrl;
  final String buttonText;

  ImageCarouselPage({
    required this.imageUrl,
    required this.buttonText,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Сторінка зі зміною картинок'),
      ),
      body: ImageButtonWidget(
        imageUrl: imageUrl,
        buttonText: buttonText,
      ),
    );
  }
}
