import 'package:flutter/material.dart';

class ImageButtonWidget extends StatefulWidget {
  final String imageUrl;
  final String buttonText;

  ImageButtonWidget({
    required this.imageUrl,
    required this.buttonText,
  });

  @override
  _ImageButtonWidgetState createState() => _ImageButtonWidgetState();
}

class _ImageButtonWidgetState extends State<ImageButtonWidget> {
  int _imageIndex = 0;

  void _changeImage() {
    setState(() {
      _imageIndex = (_imageIndex + 1) %
          3; // Змінюємо 3 на кількість зображень, яку ви маєте
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.network(widget.imageUrl),
        ElevatedButton(
          onPressed: _changeImage,
          child: Text('Змінити картинку'),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('На головну'),
        ),
      ],
    );
  }
}
