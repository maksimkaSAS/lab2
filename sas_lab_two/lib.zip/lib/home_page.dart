import 'package:flutter/material.dart';
import 'package:sas_lab_two/widgets/image_button_widget.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Головна сторінка'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ImageButtonWidget(
            imageUrl:
                'https://st.depositphotos.com/1899425/1623/i/600/depositphotos_16232649-stock-photo-moraine-lake-sunrise-colorful-landscape.jpg',
            buttonText: 'Перейти на сторінку 1',
          ),
          ImageButtonWidget(
            imageUrl:
                'https://st3.depositphotos.com/13194036/17348/i/600/depositphotos_173483674-stock-photo-stylish-dogs-in-sunglasses.jpg',
            buttonText: 'Перейти на сторінку 2',
          ),
          ImageButtonWidget(
            imageUrl:
                'https://st2.depositphotos.com/1000504/6464/i/600/depositphotos_64645823-stock-photo-paleo-diet-products.jpg',
            buttonText: 'Перейти на сторінку 3',
          ),
        ],
      ),
    );
  }
}
