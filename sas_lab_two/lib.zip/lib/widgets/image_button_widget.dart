import 'package:flutter/material.dart';
import 'package:sas_lab_two/image_carousel_page.dart';

class ImageButtonWidget extends StatelessWidget {
  final String imageUrl;
  final String buttonText;

  ImageButtonWidget({
    required this.imageUrl,
    required this.buttonText,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.network(imageUrl),
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ImageCarouselPage(
                  imageUrl: imageUrl,
                  buttonText: buttonText,
                ),
              ),
            );
          },
          child: Text(buttonText),
        ),
      ],
    );
  }
}
